# MS Official - Standalone Backend Server & REST API

Complete production backend for the **MS Official** platform, featuring user authentication, package tier management, payment verifications, daily attendance ledger, referral & affiliate bonus calculation, instant withdrawals, live support tickets, and admin super portal operations.

---

## ⚡ Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
```

### 3. Run Development Server (with hot reloading)
```bash
npm run dev
```
Backend will start on `http://localhost:5000`.

### 4. Run Production Server
```bash
npm start
```

---

## 📁 Directory Structure
```
├── server.ts             # Express server entry point with CORS & body parsing
├── server/
│   ├── api.ts            # Complete REST API router (all 30+ endpoints)
│   └── db.ts             # Transactional JSON database engine & data models
├── data/
│   └── database.json     # Persistent database with seeded packages & admin
├── uploads/              # Storage directory for receipt screenshots & attachments
│   ├── screenshots/
│   ├── payments/
│   ├── support/
│   └── general/
├── package.json          # Dependencies & scripts
├── tsconfig.json         # TypeScript configuration
└── .env.example          # Environment variables template
```

---

## 🔑 Default Admin Logins
- **Email**: `developeralihusnain@gmail.com`
- **Password**: `admin123`
- **Secondary Admin**: `admin@msofficial.com` / `admin123`

---

## 🌐 Connecting from Frontend
In your React/Vue/Next.js frontend `.env`:
```env
VITE_API_URL=http://localhost:5000/api
```
All API routes (`/api/auth/*`, `/api/packages/*`, `/api/attendance/*`, `/api/wallet/*`, `/api/admin/*`) will connect seamlessly.
