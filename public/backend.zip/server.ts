import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import cors from 'cors';
import fs from 'fs';
import { apiRouter } from './server/api.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 5000;

  // CORS configuration to allow connections from frontend clients
  app.use(
    cors({
      origin: true,
      credentials: true,
    })
  );

  // Body parser with 25MB limit for attachments & screenshots
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));

  // Ensure uploads directory exists
  const uploadsDir = path.resolve(process.cwd(), 'uploads');
  const uploadSubdirs = ['screenshots', 'payments', 'support', 'general'];
  try {
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }
    for (const sub of uploadSubdirs) {
      const subPath = path.join(uploadsDir, sub);
      if (!fs.existsSync(subPath)) {
        fs.mkdirSync(subPath, { recursive: true });
      }
    }
  } catch (dirErr) {
    console.warn('[Server] Notice during uploads dir initialization:', dirErr);
  }

  // Serve backend screenshot uploads statically
  app.use('/uploads', express.static(uploadsDir));

  // Domain Verification endpoints (Aster Mail, DNS TXT, web verification)
  const ASTER_VERIFY_PAYLOAD = 'aster-verify=Q/MF37XXjZZduH/0BCx/1vf9cevyq+YVUH9aD23uBek=';
  app.get(
    ['/_aster-verify', '/.well-known/_aster-verify', '/.well-known/aster-verify', '/aster-verify.txt', '/_aster-verify.txt'],
    (_req, res) => {
      res.type('text/plain').send(ASTER_VERIFY_PAYLOAD);
    }
  );

  // Health check endpoint
  app.get('/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'ms-official-backend',
      timestamp: new Date().toISOString(),
      database: 'connected'
    });
  });

  // Mount API router at /api
  app.use('/api', apiRouter);

  // Fallback 404 for unhandled API routes
  app.use((_req, res) => {
    res.status(404).json({ error: 'Endpoint not found' });
  });

  app.listen(PORT, '0.0.0.0', () => {
    console.log('===============================================');
    console.log(' MS Official Backend Server Active');
    console.log(` Listening on: http://0.0.0.0:${PORT}`);
    console.log(` API Base:     http://0.0.0.0:${PORT}/api`);
    console.log(` Health Check: http://0.0.0.0:${PORT}/health`);
    console.log('===============================================');
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
